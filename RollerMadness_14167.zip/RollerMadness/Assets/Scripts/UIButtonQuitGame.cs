﻿using UnityEngine;
using System.Collections;


public class UIButtonQuitGame : MonoBehaviour {

	public void quitGame()
	{
		//Closes the game
		Application.Quit();
	}
}